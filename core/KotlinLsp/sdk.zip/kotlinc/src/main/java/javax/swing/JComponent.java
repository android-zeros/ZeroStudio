package javax.swing;

public class JComponent {
}
