package javax.swing;

public class SwingUtilities {
    public static boolean isEventDispatchThread() {
        return true;
    }
}
