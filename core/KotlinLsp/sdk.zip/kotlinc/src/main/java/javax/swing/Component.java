package javax.swing;

public class Component {
}
