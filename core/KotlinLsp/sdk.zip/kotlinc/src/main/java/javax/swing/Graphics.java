package javax.swing;

public class Graphics {

}
