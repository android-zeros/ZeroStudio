package org.jetbrains.kotlin.com.intellij.psi.augment;

public class AugmentProvider extends PsiAugmentProvider {

    public AugmentProvider() {

    }
}
