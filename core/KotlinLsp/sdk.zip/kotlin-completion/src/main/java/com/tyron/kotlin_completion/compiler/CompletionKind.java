package com.tyron.kotlin_completion.compiler;

public enum CompletionKind {
    DEFAULT
}
