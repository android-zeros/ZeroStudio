package com.tyron.kotlin.completion.core.builder

import org.junit.Assert.*

class KotlinPsiManagerTest {

    fun test() {

    }
}