import java.util.List;
import java.util.ArrayList;
public class MyClass{lprivate String name;
public MyClass(String name){this.name=name;}
 public void printList(){List<Integer> list=new ArrayList<>();for(int i=0;i<10;i++){if(i % 2 == 0)list.add(i);}
System.out.println(list); }}