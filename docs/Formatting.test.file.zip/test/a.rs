mod shapes {
pub trait Area { fn area(&self) -> f64; }
pub struct Circle { pub radius: f64, }
impl Area for Circle { fn area(&self) -> f64 { std::f64::consts::PI * self.radius * self.radius } }
}
fn main() {
    let c = shapes::Circle { radius: 10.0 };
    println!("The area is {}", c.area());
    let number = 13;
    match number {
 1 => println!("One!"),
  2 | 3 | 5 | 7 | 11 => println!("This is a prime"),
 13..=19 => println!("A teen"),
    _ => println!("Ain't special"),
    }
}