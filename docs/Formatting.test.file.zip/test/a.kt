package com.example
data class User(val name:String,val age:Int)
fun main(){val users=listOf(User("Alice",20),User("Bob",30))
users.filter{it.age>25}.map{it.name}.forEach{println("User: $it")}
}