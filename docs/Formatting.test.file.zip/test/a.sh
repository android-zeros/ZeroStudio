#!/bin/bash
NAME="World"
if [ "$NAME" == "World" ]; then
echo "Hello, $NAME"
case $NAME in
"World")
echo "Planet detected"
;;
esac
fi