#include <iostream>
#include <vector>
namespace MyLib {
template<typename T>
class Container {
public:
 void add(T item) { m_data.push_back(item); }
    void print() { for(const auto& item : m_data) { std::cout << item << " "; } std::cout << std::endl; }
private:
    std::vector<T> m_data;
};
}
int main() { MyLib::Container<int> c; c.add(1); c.add(2); c.print(); return 0; }