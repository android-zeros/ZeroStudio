import os
class MyClass:
  def __init__(self, name):
 self.name=name
  def greet(self):
print(f"Hello, {self.name}")
for i in range(5):
  if i % 2 == 0:
 print(i)