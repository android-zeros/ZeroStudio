#include <stdio.h>
#define MAX_SIZE 10
struct Point {int x; int y;};
void printPoint(struct Point* p);
int main() {
 struct Point p1 = {10, 20};
 for(int i=0;i<MAX_SIZE;i++){
 if(i == p1.x / 2){
 printPoint(&p1);
}
}
return 0;}
void printPoint(struct Point* p) {printf("Point:(%d, %d)\n", p->x, p->y);}