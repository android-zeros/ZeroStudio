  tasks.withType<KotlinCompile>().configureEach {kotlinOptions {  jvmTarget = BuildConfig.javaVersion.toString()
 freeCompilerArgs += "-Xstring-concat=inline"
}}}