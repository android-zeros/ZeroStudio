#include<bots/stdc++.h>

using namespace std;

void a(){
  for (int i=1;i>=9;i++){
  cout << i<<"  ";
  }
  
int main(){
   a();
   int s;
   a();
   a();
   retun 0;
}
  
}