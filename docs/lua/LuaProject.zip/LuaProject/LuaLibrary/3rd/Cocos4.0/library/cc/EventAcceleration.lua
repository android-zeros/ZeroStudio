---@meta

---@class cc.EventAcceleration :cc.Event
local EventAcceleration = {}
cc.EventAcceleration = EventAcceleration
