---@meta

---@class cc.EaseCircleActionOut :cc.ActionEase
local EaseCircleActionOut = {}
cc.EaseCircleActionOut = EaseCircleActionOut

---*
---@param action cc.ActionInterval
---@return self
function EaseCircleActionOut:create(action) end
---*
---@return self
function EaseCircleActionOut:clone() end
---*
---@param time float
---@return self
function EaseCircleActionOut:update(time) end
---*
---@return cc.ActionEase
function EaseCircleActionOut:reverse() end
---*
---@return self
function EaseCircleActionOut:EaseCircleActionOut() end
