local config = require 'config.config'

return config
