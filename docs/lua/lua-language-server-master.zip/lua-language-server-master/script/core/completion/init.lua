return require 'core.completion.completion'
