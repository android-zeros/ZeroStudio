local brave = require 'brave.brave'
require 'brave.work'

return brave
