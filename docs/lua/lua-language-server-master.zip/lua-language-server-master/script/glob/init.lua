return {
    glob = require 'glob.glob',
    gitignore = require 'glob.gitignore',
}
