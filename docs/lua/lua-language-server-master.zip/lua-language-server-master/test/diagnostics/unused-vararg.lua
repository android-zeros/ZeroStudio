TEST [[
local function f(<!...!>)
    return 'something'
end
f()
]]
