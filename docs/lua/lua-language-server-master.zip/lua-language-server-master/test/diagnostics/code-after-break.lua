TEST [[
while true do
    break
    <!print()
    print()!>
end
]]
