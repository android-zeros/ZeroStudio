TEST [[
---@class A
---@operator <!xxx!>: A
]]
