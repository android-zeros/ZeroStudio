TEST [[
---@class A : <!B!>
]]
