TEST [[
---@diagnostic disable-next-line: <!xxx!>
]]
