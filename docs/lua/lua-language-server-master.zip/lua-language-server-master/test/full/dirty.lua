TEST [[
a.
]]

TEST [[
a:
]]

TEST [[
end
]]

TEST [[
table.02X
]]
