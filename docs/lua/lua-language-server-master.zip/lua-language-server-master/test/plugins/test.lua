require 'plugins.ast.test'
require 'plugins.ffi.test'
require 'plugins.node.test'
