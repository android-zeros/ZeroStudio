package.path = package.path .. ';script/?.lua;tools/?.lua'

dofile 'tools/love-api.lua'
dofile 'tools/lovr-api.lua'
dofile 'tools/normalize-3rd-path.lua'
