---@meta

local m = {}

function m.thisIsAnExampleLibrary()
end

return m
